    let Raul //comun
    const Jesus = 5 // no puede cambiar su valor
    var Edson // la variable puede cambiar en cualquier momento

// String normal
    let Apellido = "Sanchez"
// Tipo de vairable constannte 
    let Edad = 20
// untipo de variable String template 
    let Nombre = `Hector`;
// este es un arreglo
    let Nombres = ["alfredo","jesus","jose"]
// este tipo de cosas serian objetos
    let Comidas = 
    {
        "enchiladas":20, 
        "totopos":30,
        "arroz":10
    }

// tipo de dato booleanos
    EsMayor = true
    EsMenor = false


    console.log (Nombre)
