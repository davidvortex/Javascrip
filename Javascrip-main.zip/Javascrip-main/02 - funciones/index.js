a=1
b=2

function sum (a,b){
    let res = a + b;
    return res;
}


const sumar = (a, b) => a+b;

console.log(sum(a,b))
console.log(sumar(a,b))